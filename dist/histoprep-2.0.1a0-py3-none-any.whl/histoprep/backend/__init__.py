"""Slide reader backends."""

from ._czi import *
from ._openslide import *
from ._pillow import *
