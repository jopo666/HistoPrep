"""Functionals."""

from ._dearray import *
from ._draw import *
from ._metrics import *
from ._stain import *
from ._tiles import *
from ._tissue import *
