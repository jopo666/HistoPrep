"""Data classes."""

from ._coordinates import *
