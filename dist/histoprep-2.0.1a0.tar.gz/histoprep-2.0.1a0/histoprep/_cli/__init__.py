"""CLI interface functions."""

from ._cut import cut_slides
