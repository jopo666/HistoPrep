"""Slide reader backends."""

from ._czi import *
from ._data import *
from ._openslide import *
from ._pillow import *
