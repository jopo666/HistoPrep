# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['histoprep',
 'histoprep.backend',
 'histoprep.backend._data',
 'histoprep.backend._functional',
 'histoprep.cli',
 'histoprep.functional',
 'histoprep.utils']

package_data = \
{'': ['*']}

install_requires = \
['aicspylibczi>=3,<4',
 'matplotlib',
 'mpire>=2.6,<3.0',
 'numpy',
 'opencv-python-headless>=4.7.0.68,<5.0.0.0',
 'openslide-python>=1.2,<2.0',
 'pillow>=9,<10',
 'polars>=0.16,<0.17',
 'rich-click>=1.6,<2.0',
 'scikit-learn>=1,<2',
 'tqdm']

entry_points = \
{'console_scripts': ['HistoPrep = histoprep.cli._cut:cut_slides']}

setup_kwargs = {
    'name': 'histoprep',
    'version': '2.0.1a0',
    'description': 'Read and process histological slide images with python!',
    'long_description': '<div align="center">\n\n# HistoPrep\nPreprocessing large medical images for machine learning made easy!\n\n<p align="center">\n    <a href="#version" alt="Version">\n        <img src="https://img.shields.io/pypi/v/histoprep"/></a>\n    <a href="#licence" alt="Licence">\n        <img src="https://img.shields.io/github/license/jopo666/HistoPrep"/></a>\n    <a href="#issues" alt="Issues">\n        <img src="https://img.shields.io/github/issues/jopo666/HistoPrep"/></a>\n    <a href="#activity" alt="Activity">\n        <img src="https://img.shields.io/github/last-commit/jopo666/HistoPrep"/></a>\n</p>\n\n<p align="center">\n  <a href="#usage">Description</a> •\n  <a href="#installation">Installation</a> •\n  <a href="#examples">Examples</a> •\n  <a href="#documentation">Documentation</a> •\n  <a href="#citation">Citation</a>\n</p>\n\n</div>\n\n\n## Description\n\nThis module allows you to easily **cut** and **preprocess** large histological slides\nfrom the CLI or programmatically!\n\n```bash\njopo666@~$ HistoPrep -i \'./slides/*.tiff\' -o ./tiles --width 512 --overlap 0.25\n```\n\n\n```python\n# TODO: Add cutting example.\n```\n\n```python\n# TODO: Add derray example.\n```\n\n```python\n# TODO: Add preprocess example.\n```\n\n## Installation \n\n```bash \npip install histoprep\n```\n\nor as an excecutable from your command line!\n\n\n\n## Examples\n\n```python\n# TODO: Add detailed examples.\n```\n\n## Documentation\n\n```python\n# TODO: Add documentation.\n```\n\n## Citation\n\nIf you use `HistoPrep` in a publication, please cite the github repository.\n\n```\n@misc{histoprep,\n  author = {Pohjonen, Joona and Ariotta, Valeria},\n  title = {HistoPrep: Preprocessing large medical images for machine learning made easy!},\n  year = {2022},\n  publisher = {GitHub},\n  journal = {GitHub repository},\n  howpublished = {https://github.com/jopo666/HistoPrep},\n}\n```\n',
    'author': 'jopo666',
    'author_email': 'jopo@birdlover.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
